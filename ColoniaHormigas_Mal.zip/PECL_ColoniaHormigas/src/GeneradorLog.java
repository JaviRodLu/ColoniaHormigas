public class GeneradorLog {
    
}
