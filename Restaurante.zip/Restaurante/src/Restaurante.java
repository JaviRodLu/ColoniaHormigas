
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;
import javax.swing.JTextField;


        
public class Restaurante {
Random n = new Random();
    GeneradorLog generadorLog;
    private Semaphore tunelEntradaExterior, tunelEntradaInterior;
    
    

    
    private ListaThreads listaClientesFuera,listaClientesDentro;
            
        
    public Restaurante (GeneradorLog gl,JTextField campoClientesFuera, JTextField campoClientesDentro) {
        this.generadorLog = gl;
        this.tunelEntradaExterior = new Semaphore(1);
        this.tunelEntradaInterior = new Semaphore(20);
        
        
        this.listaClientesFuera = new ListaThreads(campoClientesFuera);
        this.listaClientesDentro = new ListaThreads (campoClientesDentro);
        
    }

    
    public void entradaExterior(Clientes c) throws IOException {
        try {
            tunelEntradaExterior.acquire();
            System.out.println("El cliente " + c.getIdentificador() + " esta esperando en el exterior");
            listaClientesFuera.meter(c);
            generadorLog.imprimir("El cliente " + c.getIdentificador() + " esta esperando en el exterior");
            //Thread.sleep(100);
        } catch (InterruptedException | Error ex) {
        } finally {
            tunelEntradaExterior.release();
           
        }
    }
    
    
    public void entradaInterior (Clientes c) throws IOException {
    
    
    }


  

}

    

 
