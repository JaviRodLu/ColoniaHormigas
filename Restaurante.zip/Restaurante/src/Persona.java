public class Persona extends Thread {

    private String identificador;
    private int num;
    private Restaurante r;
    private Paso paso;

    public Persona (int num, Restaurante restaurante, Paso p) {
        this.num = num;
        this.r = restaurante;
        this.paso = p;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public Restaurante getR() {
        return r;
    }

    public void setR(Restaurante r) {
        this.r = r;
    }

   public Paso getPaso() {
        return paso;
    }

    public void setPaso(Paso paso) {
        this.paso = paso;
    }
    
}