
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Clientes extends Persona {
    
        public Clientes(int num, Restaurante restaurante, Paso paso) {
        super(num, restaurante, paso);
        if (num < 1) {
            this.setIdentificador("CL0000" + num);
        } else if (num < 10) {
            this.setIdentificador("CL000" + num);
        } else if (num < 100) {
            this.setIdentificador("CL00" + num);
        }else if (num < 1000) {
            this.setIdentificador("CL0" + num);
        } else {
            this.setIdentificador("CL" + num);
        }
    }
        
        @Override
        public void run() {
        try{
            int num = this.getNum();
            this.getPaso().mirar();
            this.getR().entradaExterior(this);
            this.getPaso().mirar();
            //this.getR().entradaInterior(this);
        }catch (IOException ex){
                Logger.getLogger(Clientes.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
}
            
            
            
       
    

